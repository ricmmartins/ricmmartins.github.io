<?php get_header();?>

		<div id="header_inner">
			<div id="header_inner_left"><?php include('sidebar/sidebar_blog_top.php'); ?></div>
			<div id="header_inner_right">
			  <?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
			  <?php /* If this is a category archive */ if (is_category()) { ?>
				<h1 class="title">&#8216;<?php single_cat_title(); ?>&#8217; Category</h1>
			  <?php /* If this is a tag archive */ } elseif( is_tag() ) { ?>
				<h1 class="title">Posts Tagged &#8216;<?php single_tag_title(); ?>&#8217;</h1>
			  <?php /* If this is a daily archive */ } elseif (is_day()) { ?>
				<h1 class="title">Archive for <?php the_time('F jS, Y'); ?></h1>
			  <?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
				<h1 class="title">Archive for <?php the_time('F, Y'); ?></h1>
			  <?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
				<h1 class="title">Archive for <?php the_time('Y'); ?></h1>
			  <?php /* If this is an author archive */ } elseif (is_author()) { ?>
				<h1 class="title">Author Archive</h1>
			  <?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
				<h1 class="title">Blog Archives</h1>
			  <?php } ?>
			
			</div>
		</div>
		</div><!-- end centercolumn -->
	</div><!-- end container -->
	
	<!-- BEGIN CONTENT -->
	<div id="container-content">
		<div class="centercolumn">
			<div id="content">
				<div id="contentleft">
					<div id="maincontent">
							<?php if (have_posts()) : ?>
					
					
					
							<?php while (have_posts()) : the_post(); ?>
							<div <?php post_class() ?>>
									<h2 id="post-<?php the_ID(); ?>"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
									<small><span class="info"><?php the_time('F jS, Y') ?> by <?php the_author() ?> | <?php comments_popup_link('No Comments &#187;', '1 Comment &#187;', '% Comments &#187;'); ?></span></small>
									<div class="entry_blog">
										<?php the_content('Read more...') ?>
									</div>
								</div>
					
							<?php endwhile; ?>
					
							<div class="navigation">
								<div class="alignleft"><?php next_posts_link('&laquo; Older Entries') ?></div>
								<div class="alignright"><?php previous_posts_link('Newer Entries &raquo;') ?></div>
							</div>
						<?php else :
					
							if ( is_category() ) { // If this is a category archive
								printf("<h2 class='center'>Sorry, but there aren't any posts in the %s category yet.</h2>", single_cat_title('',false));
							} else if ( is_date() ) { // If this is a date archive
								echo("<h2>Sorry, but there aren't any posts with this date.</h2>");
							} else if ( is_author() ) { // If this is a category archive
								$userdata = get_userdatabylogin(get_query_var('author_name'));
								printf("<h2 class='center'>Sorry, but there aren't any posts by %s yet.</h2>", $userdata->display_name);
							} else {
								echo("<h2 class='center'>No posts found.</h2>");
							}
							get_search_form();
					
						endif;
						?>
					</div><!-- end maincontent -->
				</div><!-- end contentleft -->
				<div id="side">
				<div class="sidebox">
					<div class="sidebox-bgtop">
					<div class="sidebox-bgbottom">
					<div class="sidebox-padding">
						<?php include('sidebar/sidebar_blog_right.php'); ?>
					</div><!-- end sidebox padding -->
					</div><!-- end sidebox bgbottom -->
					</div><!-- end sidebox bgtop -->
				</div><!-- end sidebox -->
				</div><!-- end side -->
				<div class="clr"></div><!-- clear float -->
			</div><!-- end content -->
		</div><!-- end centercolumn -->
	</div><!-- end container-content -->
	<!-- END CONTENT -->
<?php get_footer(); ?>
