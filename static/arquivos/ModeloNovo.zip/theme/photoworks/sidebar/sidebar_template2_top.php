
	<div id="sidebartop">
		<ul>
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar(14) ) : ?>

				<li>&nbsp;</li>

			<?php endif; ?>
		</ul>
	</div>

