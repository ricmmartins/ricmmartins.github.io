
	<div id="sidebar">
		<ul>
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar(17) ) : ?>

				<li><h2>Sidebar Extra3 Right</h2>
					<ul>
						<li>This is sidebar extra3 right. Change this sidebar via wordpress admin under Appearance - Widgets</li>
					</ul>
				</li>

			<?php endif; ?>
		</ul>
		
	</div>

