<?php 
/*
Template Name: Template Contact
*/
?>
<?php 
//If the form is submitted
if(isset($_POST['submitted'])) {

	//Check to see if the honeypot captcha field was filled in
	if(trim($_POST['checking']) !== '') {
		$captchaError = true;
	} else {
	
		//Check to make sure that the name field is not empty
		if(trim($_POST['contactName']) === '') {
			$nameError = 'You forgot to enter your name.';
			$hasError = true;
		} else {
			$name = trim($_POST['contactName']);
		}
		
		//Check to make sure sure that a valid email address is submitted
		if(trim($_POST['email']) === '')  {
			$emailError = 'You forgot to enter your email address.';
			$hasError = true;
		} else if (!eregi("^[A-Z0-9._%-]+@[A-Z0-9._%-]+\.[A-Z]{2,4}$", trim($_POST['email']))) {
			$emailError = 'You entered an invalid email address.';
			$hasError = true;
		} else {
			$email = trim($_POST['email']);
		}
			
		//Check to make sure comments were entered	
		if(trim($_POST['comments']) === '') {
			$commentError = 'You forgot to enter your comments.';
			$hasError = true;
		} else {
			if(function_exists('stripslashes')) {
				$comments = stripslashes(trim($_POST['comments']));
			} else {
				$comments = trim($_POST['comments']);
			}
		}
			
		//If there is no error, send the email
		if(!isset($hasError)) {
			$getemail = get_option('photoworks_email');
			$getsubject = get_option('photoworks_email_subject');
			
			if($getemail == ""){
			$emailTo = 'testmail@templatesquare.com';
			}else{
			$emailTo = $getemail;
			}
			
			if($getsubject == ""){
			$subject = 'Photoworks Contact Form';
			}else{
			$subject = $getsubject;
			}
/*			$sendCopy = trim($_POST['sendCopy']);
*/			$body = "Name: $name \n\nEmail: $email \n\nMessage: $comments";
			$headers = 'From: '.$name.' <'.$email.'>' . "\r\n" . 'Reply-To: ' . $email;
			
			mail($emailTo, $subject, $body, $headers);

/*			if($sendCopy == true) {
				$subject = 'You emailed Your Name';
				$headers = 'From: Your Name <noreply@somedomain.com>';
				mail($email, $subject, $body, $headers);
			}

*/			$emailSent = true;

		}
	}
} ?>
<?php get_header(); ?>

		<div id="header_inner">
			<div id="header_inner_left"><?php include('sidebar/sidebar_contact_top.php'); ?></div>
			<div id="header_inner_right"><h1 class="title"><?php the_title(); ?></h1></div>
		</div>
		</div><!-- end centercolumn -->
	</div><!-- end container -->
	
	<!-- BEGIN CONTENT -->
	<div id="container-content">
		<div class="centercolumn">
		<div id="content">
			<div id="contentleft">
				<div id="maincontent">
				<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/contact-form.js"></script>
					<?php if(isset($emailSent) && $emailSent == true) { ?>
					
						<div class="thanks">
							<h1>Thanks, <?php echo $name;?></h1>
							<p>Your email was successfully sent. I will be in touch soon.</p>
						</div>
					
					<?php } else { ?>
					
						<?php if (have_posts()) : ?>
						
						<?php while (have_posts()) : the_post(); ?>
							<div class="entry">
							<?php the_content('<p>Read more...</p>'); ?>
							<?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
							</div>
							<br  />
							
							<?php if(isset($hasError) || isset($captchaError)) { ?>
								<p class="error">There was an error submitting the form.<p>
							<?php } ?>
						
							<form action="<?php the_permalink(); ?>" id="contactForm" method="post">
						
								<ol class="forms">
									<li><label for="contactName">Name</label>
										<input type="text" name="contactName" id="contactName" value="<?php if(isset($_POST['contactName'])) echo $_POST['contactName'];?>" class="requiredField" />
										<?php if($nameError != '') { ?>
											<span class="error"><?php echo $nameError;?></span> 
										<?php } ?>
									</li>
									
									<li><label for="email">Email</label>
										<input type="text" name="email" id="email" value="<?php if(isset($_POST['email']))  echo $_POST['email'];?>" class="requiredField email" />
										<?php if($emailError != '') { ?>
											<span class="error"><?php echo $emailError;?></span>
										<?php } ?>
									</li>
									
									<li class="textarea"><label for="commentsText">Message</label>
										<textarea name="comments" id="commentsText" rows="5" cols="30" class="requiredField"><?php if(isset($_POST['comments'])) { if(function_exists('stripslashes')) { echo stripslashes($_POST['comments']); } else { echo $_POST['comments']; } } ?></textarea>
										<?php if($commentError != '') { ?>
											<span class="error"><?php echo $commentError;?></span> 
										<?php } ?>
									</li>
									
								<!--	<li class="inline"><input type="checkbox" name="sendCopy" id="sendCopy" value="true"<?php if(isset($_POST['sendCopy']) && $_POST['sendCopy'] == true) echo ' checked="checked"'; ?> />
									<label for="sendCopy">Send a copy of this email to yourself</label></li> -->
									
									<li class="screenReader"><label for="checking" class="screenReader">If you want to submit this form, do not enter anything in this field</label><input type="text" name="checking" id="checking" class="screenReader" value="<?php if(isset($_POST['checking']))  echo $_POST['checking'];?>" /></li>
									<li class="buttons"><input type="hidden" name="submitted" id="submitted" value="true" /><button type="submit" value="send"></button></li>
								</ol>
								<br style="clear:both" />
							</form>
							
							<?php endwhile; ?>
						<?php endif; ?>
					<?php } ?>
				</div><!-- end maincontent -->
			</div><!-- end contentleft -->
			<div id="side">
			<div class="sidebox">
				<div class="sidebox-bgtop">
				<div class="sidebox-bgbottom">
				<div class="sidebox-padding">
					<?php include('sidebar/sidebar_contact_right.php'); ?>
				</div><!-- end sidebox padding -->
				</div><!-- end sidebox bgbottom -->
				</div><!-- end sidebox bgtop -->
			</div><!-- end sidebox -->
			</div><!-- end side -->
			<div class="clr"></div><!-- clear float -->
		</div><!-- end content -->
		</div><!-- end centercolumn -->
	</div><!-- end container-content -->
	<!-- END CONTENT -->
<?php get_footer(); ?>
